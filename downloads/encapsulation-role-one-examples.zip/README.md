# 封装、访问控制与包管理编译实验

角色一提供源码与正反例。各组互相独立，从压缩包解压后的目录开始，每组单独建立 classes 输出目录。

## ENC-02 构造时校验

在 ENC-02 目录运行：

    javac -encoding UTF-8 -d classes 正例/BankAccount.java 正例/Demo.java
    java -cp classes Demo

预期输出 10，随后是 initial rejected。

## PKG-03 同名类消歧

在 PKG-03 目录运行：

    javac -encoding UTF-8 -d classes 正例/one/Item.java 正例/two/Item.java 正例/Demo.java
    java -cp classes Demo
    javac -encoding UTF-8 -cp classes -d classes 反例/Bad.java
    javac -encoding UTF-8 -cp classes -d classes 反例/Ambiguous.java

正例依次输出 one.Item 和 two.Item。前一个反例在重复的显式导入处报错，后一个反例在使用歧义简单名时出错。

## PKG-04 通配符与子包权限

在 PKG-04 目录运行：

    javac -encoding UTF-8 -d classes 正例/school/Parent.java 正例/school/app/Child.java 正例/Demo.java
    java -cp classes Demo
    javac -encoding UTF-8 -cp classes -d classes 反例/BadImport.java
    javac -encoding UTF-8 -cp classes -d classes 反例/school/app/BadAccess.java

正例依次输出 school.Parent 和 school.app.Child。反例分别验证通配符不会导入子包类型、子包不能读取父包的包级字段。
