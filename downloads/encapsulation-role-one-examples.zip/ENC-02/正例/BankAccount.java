public class BankAccount {
    private int balance;

    public BankAccount(int initial) {
        if (initial < 0) throw new IllegalArgumentException("initial");
        balance = initial;
    }

    public int balance() {
        return balance;
    }

    public void deposit(int amount) {
        if (amount <= 0 || amount > Integer.MAX_VALUE - balance) {
            throw new IllegalArgumentException("deposit");
        }
        balance += amount;
    }

    public void withdraw(int amount) {
        if (amount <= 0 || amount > balance) {
            throw new IllegalArgumentException("withdraw");
        }
        balance -= amount;
    }
}
