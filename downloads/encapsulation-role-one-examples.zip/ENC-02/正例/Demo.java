public class Demo {
    public static void main(String[] args) {
        System.out.println(new BankAccount(10).balance());
        try {
            new BankAccount(-1);
            throw new AssertionError("expected rejection");
        } catch (IllegalArgumentException expected) {
            System.out.println("initial rejected");
        }
    }
}
