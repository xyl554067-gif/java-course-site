import one.*;
import two.*;
class Ambiguous { Item item; }
