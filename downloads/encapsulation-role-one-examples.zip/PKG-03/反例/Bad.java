import one.Item;
import two.Item;
class Bad {}
