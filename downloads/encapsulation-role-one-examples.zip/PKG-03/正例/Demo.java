import one.Item;

public class Demo {
    public static void main(String[] args) {
        System.out.println(new Item().getClass().getName());
        System.out.println(new two.Item().getClass().getName());
    }
}
