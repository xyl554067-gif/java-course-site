package school.app;
class BadAccess { int read(school.Parent value) { return value.local; } }
