import school.*;
class BadImport { Child value; }
