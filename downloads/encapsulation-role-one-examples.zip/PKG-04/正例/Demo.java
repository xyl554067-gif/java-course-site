import school.*;
import school.app.Child;

public class Demo {
    public static void main(String[] args) {
        System.out.println(new Parent().getClass().getName());
        System.out.println(new Child().getClass().getName());
    }
}
