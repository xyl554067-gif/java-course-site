package school;
public class Parent { int local = 1; }
