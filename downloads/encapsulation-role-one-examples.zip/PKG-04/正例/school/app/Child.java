package school.app;
public class Child {}
