package demo.bank;

public class Account {
    private int balance = 100;

    public int getBalance() {
        return balance;
    }

    String branchCode() {
        return "BANK";
    }
}
