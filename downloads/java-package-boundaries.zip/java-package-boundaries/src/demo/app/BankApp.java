package demo.app;

import demo.bank.Account;

public class BankApp {
    public static void main(String[] args) {
        Account account = new Account();
        System.out.println(account.branchCode()); // 这里故意保留错误
    }
}
