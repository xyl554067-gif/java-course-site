# 双包实验 · 复现并修复跨包访问错误

需要 JDK 17 或更新版本。

- IntelliJ IDEA：打开 pom.xml，并选择作为 Maven 项目打开。
- VS Code：装好 Java 扩展后，打开解压得到的 java-package-boundaries 目录。

先编译一次。BankApp.java 中的 branchCode() 只有包访问权限，demo.app 里的入口无法调用它。初始工程故意保留此处编译错误。

把 BankApp.java 里的 account.branchCode() 改成 account.getBalance()。再次编译并运行 BankApp.main，应该输出 100。

也可以在包含 pom.xml 的目录使用终端。先执行这一条观察报错，修复后用同一条命令重新编译。

```bash
javac -encoding UTF-8 -d out src/demo/bank/Account.java src/demo/app/BankApp.java
```

编译成功后运行。

```bash
java -cp out demo.app.BankApp
```
